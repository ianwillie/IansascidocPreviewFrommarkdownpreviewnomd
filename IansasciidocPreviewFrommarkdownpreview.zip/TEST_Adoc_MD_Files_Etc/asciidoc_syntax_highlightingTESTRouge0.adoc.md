= AsciiDoc Syntax
:safe: safe
:icons: font
:stem:
:toc:
:doctype: book
//:url-docs: https://asciidoctor.org/docs
//:url-gem: https://rubygems.org/gems/asciidoctor
:source-highlighter: rouge

//:styledir: tempZ
//:stylesheet: asciidoctor.css


== AsciiDoc Syntax 9999999999999999888777666

THis is a very  line to test


.Some Ruby CodeX
[source, ruby]

----
require 'sinatra'

get '/hi' do
  "Hello World"
end
----

.Some HTML Code
[source, html]

----

<a href="adfgef">Text Sections adfgef</a>
----



`+12345678911234567892123456789312345678941234567895123456789612345678971234567898123456789912345678901234567891123456789212345678931234567894123456789512345678961234567897123456789812345678991234567890+` +
`+0........1.........2.........3.........4.........5.........6.........7.........8........9.........10........11........12........13........14........15........16........17........18........19........20+` +

// thematic break (aka horizontal rule)
---

// page break
<<<

This the is END of file +
Look at Middleman website here "http://localhost:35729/livereload.js"
