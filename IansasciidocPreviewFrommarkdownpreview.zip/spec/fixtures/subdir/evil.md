hello
<script src="index.js"></script>
<script>alert('rm -fr')</script>
<img onload="alert('rm -rf')" onerror="alert('rm -fr')">
world
