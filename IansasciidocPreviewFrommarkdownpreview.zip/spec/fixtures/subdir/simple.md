*italic*

**bold**

encoding → issue
